<!-- ICI JE NE MET QUE DU PHP!!! -->
<?php
Header::set_title("Module  : par défaut");
include("default.php");
?>
