<!-- ICI J'UTILISE LE HTML!!! LE PHP N'EST UTILISÉ QUE POUR LES BOUCLES
L'INITIALISATION DE MES VARIABLES PHP SE FONT DANS LE MODULE! -->

<h1>Module par défaut</h1>
<p>
Ceci est le module chargé par défaut
</p>
