-- Script d'insertion en base
INSERT INTO tRayon VALUES ("Frais libre service");
INSERT INTO tRayon VALUES ("Frais traditionnel");
INSERT INTO tRayon VALUES ("Liquides");
INSERT INTO tRayon VALUES ("Loisirs");
INSERT INTO tRayon VALUES ("Textile");
INSERT INTO tRayon VALUES ("Epicerie");
INSERT INTO tRayon VALUES ("Droguerie Hygiène");
INSERT INTO tRayon VALUES ("Surgelés");
INSERT INTO tRayon VALUES ("Equipement de la maison");

CREATE TABLE IF NOT EXISTS tProduit(
	id INT PRIMARY KEY,
	nom VARCHAR(200),
	datePeremption INT,
	prixDeBase FLOAT,
	stock INT,
	categorie VARCHAR(200),
	baremePromo FLOAT
);

CREATE TABLE IF NOT EXISTS tAssociation(
	id INT NOT NULL,
	theme VARCHAR(50) NOT NULL,
	FOREIGN KEY (id) REFERENCES tProduit (id),
	FOREIGN KEY (theme) REFERENCES tRayon (theme),
	PRIMARY KEY (id, theme) -- Clé binaire
);

CREATE TABLE IF NOT EXISTS tClient(
	login VARCHAR(50) PRIMARY KEY,
	mdp VARCHAR(50) NOT NULL,
	nom VARCHAR(100) NOT NULL,
	prenom VARCHAR(100) NOT NULL,
	adresse VARCHAR(200),
	age INT,
	pointFidelite INT
);

CREATE TABLE IF NOT EXISTS tPanier(
	id INT PRIMARY KEY,
	datePanier INT,
	login VARCHAR(50),
	FOREIGN KEY (login) REFERENCES tClient (login)
);

CREATE TABLE IF NOT EXISTS tContient(
	idProduit INT NOT NULL,
	idPanier INT NOT NULL,
	quantite INT,
	prixPublicUnitaire FLOAT,
	FOREIGN KEY (idProduit) REFERENCES tProduit (id),
	FOREIGN KEY (idPanier) REFERENCES tPanier (id),
	PRIMARY KEY (idProduit, idPanier) -- Clé binaire
);

CREATE TABLE IF NOT EXISTS tResponsableLivraison(
	login VARCHAR(50) PRIMARY KEY,
	mdp VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS tResponsableCatalogue(
	login VARCHAR(50) PRIMARY KEY,
	mdp VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS tLivreur(
	login VARCHAR(50) PRIMARY KEY,
	mdp VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS tResponsableMarketing(
	login VARCHAR(50) PRIMARY KEY,
	mdp VARCHAR(50) NOT NULL,
	baremePoint FLOAT
);

CREATE TABLE IF NOT EXISTS tTournee(
	id INT PRIMARY KEY, -- CHECK (id IN tLivreur), Contrainte impossible
	dateTournee INT NOT NULL
);

CREATE TABLE IF NOT EXISTS tRealise(
	idTournee INT NOT NULL,
	idLivreur VARCHAR(50) NOT NULL,
	FOREIGN KEY (idTournee) REFERENCES tTournee (id),
	FOREIGN KEY (idLivreur) REFERENCES tLivreur (login),
	PRIMARY KEY (idTournee, idLivreur)
);

-- Création d'un type ENUM pour tCommande.etat

CREATE TYPE eEtat AS ENUM ('en préparation', 'disponible', 'traitée');

-- Exemple de requete:
-- 	SELECT e.enumlabel 
--	FROM pg_enum e 
--	JOIN pg_type t ON (t.oid=e.enumtypid) 
--	WHERE t.typname='eEtat';

CREATE TABLE IF NOT EXISTS tCommande(
	idPanier INT PRIMARY KEY,
	dateValidation INT NOT NULL,
	etat eEtat NOT NULL,
	heureLivraison INT NOT NULL,
	lieuLivraison VARCHAR(200) NOT NULL,
	idTournee INT,
	FOREIGN KEY (idPanier) REFERENCES tPanier (id),
	FOREIGN KEY (idTournee) REFERENCES tTournee (id)
);

------------------------------------------------------------------------
------------------------------------------------------------------------
------------------------------------------------------------------------

CREATE OR REPLACE VIEW
			vCommande (	idPanier, 
						datePanier, 
						login,
						dateValidation, 
						etat, 
						heureLivraison,
						lieuLivraison, 
						idTournee
					  )
			AS 
				SELECT  tPanier.id,
						tPanier.datePanier,
						tPanier.login,
						tCommande.dateValidation,
						e.enumlabel,
						tCommande.heureLivraison,
						tCommande.lieuLivraison,
						tCommande.idTournee
				FROM tPanier, tCommande, pg_enum e
				--Jointure enum
				JOIN pg_type t ON (t.oid=e.enumtypid) 
				-- Restriction enum
				WHERE t.typname='eEtat'
				--Condition de jointure vue
				AND tPanier.id = tCommande.idPanier
